# ============================================================
#   JARVIS_V2 - Dina Wala (Aura 99999+)
#   EK HI FILE: UI + Groq AI + Voice + Commands + Memory
#   API Key embedded — GitHub Actions me bhi kaam karega
# ============================================================

import os
import sys
import json
import threading
import platform
import subprocess
import time
import random
from datetime import datetime

# ============================================================
#   🔑 API KEY — YAHAN APNI NAYI KEY PASTE KARO
# ============================================================

GROQ_API_KEY = "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"

# GitHub Actions / env variable se override (agar mile to)
_env_key = os.getenv("GROQ_API_KEY", "")
if _env_key and _env_key.startswith("gsk_"):
    GROQ_API_KEY = _env_key

# ============================================================
#   AUTO INSTALL PACKAGES (agar missing hon to)
# ============================================================

def _ensure_package(pip_name, import_name=None):
    import_name = import_name or pip_name
    try:
        __import__(import_name)
    except ImportError:
        print(f"[Setup] Installing {pip_name}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name, "--quiet"])
        except Exception as e:
            print(f"[Setup] Failed to install {pip_name}: {e}")

for pkg, imp in [
    ("flet==0.24.1", "flet"),
    ("groq==0.11.0", "groq"),
]:
    _ensure_package(pkg, imp)

# ============================================================
#   IMPORTS
# ============================================================

import flet as ft
from groq import Groq

try:
    import speech_recognition as sr
    import pyttsx3
    VOICE_AVAILABLE = True
except Exception as e:
    print(f"[Voice] missing: {e}")
    VOICE_AVAILABLE = False

# ============================================================
#   CONFIG
# ============================================================

GROQ_MODEL = "llama-3.3-70b-versatile"
USER_NAME = "Bhai"
USER_CITY = "Dina"
USER_PROJECT = "Bano Qabil"
MEMORY_FILE = "memory.json"
VOICE_GENDER = "male"

SYSTEM_PROMPT = f"""Tum JARVIS ho, ek smart AI assistant jo {USER_NAME} ka dost hai.
Tum {USER_CITY} se ho aur {USER_PROJECT} ka project ho. Aura 99999+.
Roman Urdu, Urdu, English samajhte ho. Jawab chota aur helpful rakho.
Code maange to full working code with comments do.
Dostana andaz me baat karo. Tumhara naam JARVIS hai, Dina Wala."""

SYSTEM = platform.system()
IS_MOBILE = "ANDROID_ROOT" in os.environ or "ANDROID_DATA" in os.environ

# ============================================================
#   COLORS
# ============================================================

BG_DARK = "#08090d"
BG_MID = "#0f1117"
BG_LIGHT = "#171923"
BG_HOVER = "#1e2030"
ACCENT = "#00d4ff"
ACCENT2 = "#7c3aed"
ACCENT_DIM = "#0e7490"
SUCCESS = "#4ade80"
DANGER = "#ff4757"
TEXT_MAIN = "#e6edf7"
TEXT_DIM = "#8b95a7"
TEXT_MUTED = "#4a5568"
USER_BUBBLE = "#1e40af"
BOT_BUBBLE = "#1a1f2e"

# ============================================================
#   BRAIN
# ============================================================

class JarvisBrain:
    def __init__(self):
        self.client = None
        self.messages = []
        self._load_memory()
        self._init_groq()

    def _init_groq(self):
        try:
            if not GROQ_API_KEY or not GROQ_API_KEY.startswith("gsk_"):
                raise Exception("API key missing ya galat hai")
            self.client = Groq(api_key=GROQ_API_KEY)
            self.messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.messages
            print("[Brain] Groq connected ✅")
        except Exception as e:
            print(f"[Brain] Error: {e}")
            self.client = None

    def _load_memory(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                    self.messages = json.load(f).get("messages", [])
            except Exception:
                self.messages = []

    def _save_memory(self):
        try:
            chat_only = [m for m in self.messages if m["role"] != "system"][-20:]
            with open(MEMORY_FILE, "w", encoding="utf-8") as f:
                json.dump({"messages": chat_only}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def ask_stream(self, user_message, callback):
        if not user_message.strip():
            callback("Kuch bolo to sahi bhai 😄", True)
            return
        if self.client is None:
            callback(self._offline_reply(user_message), True)
            return
        try:
            self.messages.append({"role": "user", "content": user_message})
            stream = self.client.chat.completions.create(
                model=GROQ_MODEL,
                messages=self.messages,
                temperature=0.7,
                max_tokens=1024,
                top_p=0.9,
                stream=True,
            )
            full = ""
            for chunk in stream:
                delta = chunk.choices[0].delta.content or ""
                if delta:
                    full += delta
                    callback(delta, False)
            self.messages.append({"role": "assistant", "content": full})
            self._save_memory()
            callback("", True)
        except Exception as e:
            callback(f"API error: {str(e)[:100]}", True)

    def _offline_reply(self, msg):
        m = msg.lower()
        if any(w in m for w in ["hello", "salam", "hi", "hey"]):
            return "Walaikum Salam! JARVIS offline mode me hai. Key check karo."
        if "time" in m or "waqt" in m:
            return f"Abhi {datetime.now().strftime('%I:%M %p')} baje."
        if "date" in m or "tareekh" in m:
            return f"Aaj {datetime.now().strftime('%d %B %Y')} hai."
        return "API connect nahi ho raha. Key check karo."

    def clear_memory(self):
        self.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        self._save_memory()

    def status(self):
        return "Connected ✅" if self.client else "Offline ❌"

# ============================================================
#   VOICE
# ============================================================

class VoiceOutput:
    def __init__(self):
        if not VOICE_AVAILABLE:
            return
        try:
            self.engine = pyttsx3.init()
            voices = self.engine.getProperty("voices")
            if voices:
                idx = 1 if (VOICE_GENDER == "female" and len(voices) > 1) else 0
                self.engine.setProperty("voice", voices[idx].id)
                self.engine.setProperty("rate", 180)
        except Exception as e:
            print(f"[TTS] {e}")

    def speak(self, text):
        if not VOICE_AVAILABLE or not text:
            return
        try:
            clean = text.replace("**", "").replace("*", "").replace("`", "")
            self.engine.say(clean)
            self.engine.runAndWait()
        except Exception as e:
            print(f"[TTS] {e}")

    def speak_async(self, text):
        threading.Thread(target=self.speak, args=(text,), daemon=True).start()


class VoiceInput:
    def __init__(self):
        if not VOICE_AVAILABLE:
            return
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.pause_threshold = 0.8

    def listen(self, timeout=6, phrase_limit=10):
        if not VOICE_AVAILABLE:
            return ""
        try:
            with sr.Microphone() as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_limit)
            for lang in ["ur-PK", "en-US", "hi-IN"]:
                try:
                    return self.recognizer.recognize_google(audio, language=lang)
                except sr.UnknownValueError:
                    continue
                except sr.RequestError:
                    return ""
            return ""
        except sr.WaitTimeoutError:
            return ""
        except Exception as e:
            print(f"[STT] {e}")
            return ""

# ============================================================
#   COMMANDS
# ============================================================

APP_MAP = {
    "chrome": {"Windows": "chrome", "Linux": "google-chrome", "android": "com.android.chrome"},
    "vscode": {"Windows": "code", "Linux": "code", "android": None},
    "whatsapp": {"Windows": "whatsapp", "Linux": "whatsapp", "android": "com.whatsapp"},
    "calculator": {"Windows": "calc", "Linux": "gnome-calculator", "android": "com.android.calculator2"},
}


def open_app(app_name):
    app_name = app_name.lower().strip()
    if app_name not in APP_MAP:
        return None
    cmd = APP_MAP[app_name].get(SYSTEM)
    if not cmd:
        return None
    try:
        if IS_MOBILE:
            subprocess.Popen(["am", "start", "-n", cmd])
        elif SYSTEM == "Windows":
            os.startfile(cmd)
        elif SYSTEM == "Darwin":
            subprocess.Popen(["open", "-a", cmd])
        else:
            subprocess.Popen([cmd])
        return f"'{app_name}' khol diya ✅"
    except Exception as e:
        return f"Error: {e}"


def get_time():
    return f"Abhi {datetime.now().strftime('%I:%M %p')} baje hain"


def get_date():
    return f"Aaj {datetime.now().strftime('%d %B %Y')}, {datetime.now().strftime('%A')}"


def process_command(text):
    t = text.lower().strip()
    if any(w in t for w in ["time kya", "kitne baje", "what time", "waqt kya"]):
        return get_time()
    if any(w in t for w in ["date kya", "tareekh", "what date"]):
        return get_date()
    for app in APP_MAP:
        if f"{app} kholo" in t or f"open {app}" in t:
            r = open_app(app)
            if r:
                return r
    return None

# ============================================================
#   STATE
# ============================================================

class AppState:
    def __init__(self):
        self.voice_mode = False
        self.auto_listen = False
        self.is_listening = False
        self.current_tab = 0

state = AppState()
brain = JarvisBrain()
tts = VoiceOutput() if VOICE_AVAILABLE else None
stt = VoiceInput() if VOICE_AVAILABLE else None

# ============================================================
#   UI HELPERS
# ============================================================

def _card(content, padding=15, bg=BG_MID):
    return ft.Container(
        content=content, padding=padding, bgcolor=bg,
        border_radius=14, border=ft.border.all(1, "#1f2947"),
    )


def _stat_tile(icon, label, value, color=ACCENT):
    return ft.Container(
        content=ft.Column([
            ft.Icon(icon, color=color, size=22),
            ft.Text(value, size=16, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
            ft.Text(label, size=10, color=TEXT_DIM),
        ], spacing=3, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        padding=12, bgcolor=BG_LIGHT, border_radius=12,
        border=ft.border.all(1, "#1f2947"), expand=True,
    )

# ============================================================
#   MAIN APP
# ============================================================

def main(page: ft.Page):
    page.title = "JARVIS_V2 - Dina Wala"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG_DARK
    page.padding = 0
    page.window_width = 900
    page.window_height = 720
    page.window_min_width = 400
    page.window_min_height = 600

    nav_items_data = [
        ("Chat", ft.icons.CHAT_BUBBLE_OUTLINE, 0),
        ("Commands", ft.icons.TERMINAL, 1),
        ("Settings", ft.icons.SETTINGS_OUTLINED, 2),
        ("About", ft.icons.INFO_OUTLINE, 3),
    ]

    def build_nav(idx, name, icon):
        active = idx == state.current_tab
        return ft.Container(
            content=ft.Row([
                ft.Icon(icon, size=18, color=ACCENT if active else TEXT_DIM),
                ft.Text(name, size=13, color=ACCENT if active else TEXT_DIM,
                        weight=ft.FontWeight.BOLD if active else ft.FontWeight.NORMAL),
            ], spacing=10),
            padding=ft.padding.symmetric(horizontal=14, vertical=11),
            border_radius=10, bgcolor=BG_HOVER if active else "transparent",
            on_click=lambda e, i=idx: switch_tab(i), ink=True,
        )

    nav_col = ft.Column(spacing=4, controls=[])

    def refresh_nav():
        nav_col.controls.clear()
        for idx, name, icon in nav_items_data:
            nav_col.controls.append(build_nav(idx, name, icon))
        try:
            page.update()
        except Exception:
            pass

    sidebar = ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Container(content=ft.Icon(ft.icons.SMART_TOY, color=BG_DARK, size=20),
                             bgcolor=ACCENT, padding=8, border_radius=10),
                ft.Column([
                    ft.Text("JARVIS_V2", size=16, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Siri Mode ⚡", size=10, color=TEXT_DIM),
                ], spacing=0),
            ], spacing=10),
            ft.Divider(height=1, color="#1f2947"),
            nav_col,
            ft.Container(expand=True),
            ft.Divider(height=1, color="#1f2947"),
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Container(width=8, height=8,
                                     bgcolor=SUCCESS if brain.client else DANGER,
                                     border_radius=10),
                        ft.Text("Online" if brain.client else "Offline", size=11,
                                color=SUCCESS if brain.client else DANGER),
                    ], spacing=6),
                    ft.Text("Groq Llama 3.3", size=10, color=TEXT_MUTED),
                    ft.Text(f"v2.0 • {USER_CITY}", size=10, color=TEXT_MUTED),
                ], spacing=3),
                padding=10,
            ),
        ], spacing=12),
        width=200, bgcolor=BG_MID, padding=15,
        border=ft.border.only(right=ft.border.BorderSide(1, "#1f2947")),
    )

    # ===== CHAT TAB =====
    chat_list = ft.ListView(expand=True, spacing=10, padding=15, auto_scroll=True)

    welcome_chat = ft.Container(
        content=ft.Column([
            ft.Container(content=ft.Icon(ft.icons.SMART_TOY, color=ACCENT, size=40),
                         bgcolor=BG_LIGHT, padding=20, border_radius=50,
                         border=ft.border.all(2, ACCENT)),
            ft.Text("JARVIS_V2", size=26, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
            ft.Text("Dina Wala • Aura 99999+", size=12, color=TEXT_DIM),
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.icons.BOLT, size=12, color=SUCCESS),
                    ft.Text("Groq Llama 3.3 • Siri Mode", size=11, color=SUCCESS),
                ], spacing=5, alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.symmetric(horizontal=10, vertical=5),
                bgcolor="#0d2e1a", border_radius=20,
            ),
            ft.Container(height=10),
            ft.Text(f"Salam {USER_NAME}! Kya hukum hai?", size=14, color=TEXT_MAIN),
            ft.Text("Type karo, ya mic dabao aur bolo", size=11, color=TEXT_DIM),
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
        padding=30,
    )
    chat_list.controls.append(welcome_chat)

    def add_bubble(text, is_user=False):
        if is_user:
            bubble = ft.Row([
                ft.Container(expand=True),
                ft.Container(
                    content=ft.Column([
                        ft.Text("You", size=10, color=ACCENT, weight=ft.FontWeight.BOLD),
                        ft.Text(text, size=13, color=TEXT_MAIN, selectable=True),
                    ], spacing=3),
                    bgcolor=USER_BUBBLE, padding=12, border_radius=12,
                    margin=ft.margin.only(left=60),
                ),
            ])
        else:
            bubble = ft.Row([
                ft.Container(content=ft.Icon(ft.icons.SMART_TOY, size=16, color=ACCENT),
                             bgcolor=BG_LIGHT, padding=6, border_radius=20),
                ft.Container(
                    content=ft.Column([
                        ft.Text("JARVIS", size=10, color=ACCENT, weight=ft.FontWeight.BOLD),
                        ft.Text(text if text else "▋", size=13, color=TEXT_MAIN, selectable=True),
                    ], spacing=3),
                    bgcolor=BOT_BUBBLE, padding=12, border_radius=12, expand=True,
                ),
            ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.START)
        chat_list.controls.append(bubble)
        try:
            page.update()
        except Exception:
            pass
        return bubble

    def add_system(text):
        chat_list.controls.append(ft.Container(
            content=ft.Text(text, size=11, color=TEXT_DIM, italic=True),
            alignment=ft.alignment.center, padding=6,
        ))
        try:
            page.update()
        except Exception:
            pass

    def send_text(text):
        text = (text or "").strip()
        if not text:
            return
        txt_input.value = ""
        try:
            page.update()
        except Exception:
            pass
        add_bubble(text, is_user=True)
        local_reply = process_command(text)
        if local_reply:
            add_bubble(local_reply)
            if state.voice_mode and tts:
                tts.speak_async(local_reply)
            if state.auto_listen:
                start_voice_mode()
            return

        reply_ref = {"text": ""}
        bot_bubble = add_bubble("")
        bot_text_widget = bot_bubble.controls[1].content.controls[1]

        def on_chunk(chunk, is_done):
            if chunk:
                reply_ref["text"] += chunk
                bot_text_widget.value = reply_ref["text"] + "▋"
                try:
                    page.update()
                except Exception:
                    pass
            if is_done:
                final = reply_ref["text"] or "No reply"
                bot_text_widget.value = final
                try:
                    page.update()
                except Exception:
                    pass
                if state.voice_mode and tts:
                    tts.speak_async(final)
                if state.auto_listen:
                    start_voice_mode()

        threading.Thread(target=lambda: brain.ask_stream(text, on_chunk), daemon=True).start()

    txt_input = ft.TextField(
        hint_text="Message likho ya mic dabao...",
        border_radius=25, filled=True, bgcolor=BG_LIGHT,
        border_color=ACCENT_DIM, color=TEXT_MAIN,
        hint_style=ft.TextStyle(color=TEXT_MUTED),
        expand=True, on_submit=lambda e: send_text(e.control.value),
    )

    overlay_container = ft.Container(expand=True, visible=False)

    def do_listen():
        if not VOICE_AVAILABLE or not stt:
            add_system("Voice modules nahi mile.")
            return
        if state.is_listening:
            return
        state.is_listening = True

        bars = [ft.Container(width=6, height=20, bgcolor=ACCENT, border_radius=3,
                              animate=ft.animation.Animation(200, "easeOut"))
                for _ in range(7)]
        status_text = ft.Text("Sun raha hoon...", size=16, color=TEXT_MAIN,
                               weight=ft.FontWeight.BOLD)
        result_text = ft.Text("", size=14, color=ACCENT, italic=True,
                               text_align=ft.TextAlign.CENTER)
        wave_row = ft.Row(bars, spacing=6, alignment=ft.MainAxisAlignment.CENTER)

        def on_cancel():
            state.is_listening = False
            overlay_container.visible = False
            page.update()

        cancel_btn = ft.ElevatedButton("Cancel", icon=ft.icons.CLOSE,
                                        bgcolor=BG_LIGHT, color=DANGER,
                                        on_click=lambda e: on_cancel())

        overlay = ft.Container(
            content=ft.Column([
                ft.Container(height=80),
                ft.Container(content=ft.Icon(ft.icons.MIC, size=60, color=ACCENT),
                             bgcolor=BG_LIGHT, padding=30, border_radius=100,
                             border=ft.border.all(3, ACCENT)),
                ft.Container(height=30),
                status_text,
                ft.Container(height=10),
                wave_row,
                ft.Container(height=20),
                result_text,
                ft.Container(expand=True),
                cancel_btn,
                ft.Container(height=40),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
            bgcolor="#000000ee", expand=True, padding=30,
        )

        overlay_container.content = overlay
        overlay_container.visible = True
        try:
            page.update()
        except Exception:
            pass

        def animate():
            while state.is_listening:
                for bar in bars:
                    bar.height = random.randint(15, 70)
                    bar.bgcolor = random.choice([ACCENT, ACCENT2, SUCCESS])
                try:
                    page.update()
                except Exception:
                    break
                time.sleep(0.12)

        threading.Thread(target=animate, daemon=True).start()

        def listen_worker():
            time.sleep(0.4)
            text = stt.listen(timeout=6, phrase_limit=10)
            if not state.is_listening:
                return
            if text:
                result_text.value = f'"{text}"'
                status_text.value = "Samajh gaya ✅"
                try:
                    page.update()
                except Exception:
                    pass
                time.sleep(0.5)
            else:
                status_text.value = "Kuch suna nahi ❌"
                try:
                    page.update()
                except Exception:
                    pass
                time.sleep(0.8)

            def finish():
                overlay_container.visible = False
                state.is_listening = False
                try:
                    page.update()
                except Exception:
                    pass
                if text:
                    send_text(text)
                else:
                    add_system("Kuch samajh nahi aaya.")

            page.run_thread(finish)

        threading.Thread(target=listen_worker, daemon=True).start()

    def start_voice_mode():
        threading.Thread(target=do_listen, daemon=True).start()

    def on_mic(e):
        if state.is_listening:
            state.is_listening = False
            overlay_container.visible = False
            page.update()
            return
        start_voice_mode()

    def on_send(e):
        send_text(txt_input.value)

    def on_clear(e):
        chat_list.controls = [welcome_chat]
        brain.clear_memory()
        page.update()
        add_system("Chat + memory clear ✅")

    def on_voice_toggle(e):
        state.voice_mode = voice_switch.value
        add_system(f"Bolo mode {'ON 🔊' if state.voice_mode else 'OFF 🔇'}")

    def on_auto_toggle(e):
        state.auto_listen = auto_switch.value
        add_system(f"Auto-listen {'ON 🔄' if state.auto_listen else 'OFF'}")

    mic_btn = ft.ElevatedButton(icon=ft.icons.MIC, text="Siri",
                                 bgcolor=ACCENT, color=BG_DARK, on_click=on_mic,
                                 style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=25)))
    send_btn = ft.IconButton(icon=ft.icons.SEND, icon_color=ACCENT, icon_size=26,
                              on_click=on_send,
                              style=ft.ButtonStyle(bgcolor=BG_LIGHT,
                                                   shape=ft.RoundedRectangleBorder(radius=25)))
    clear_btn = ft.IconButton(icon=ft.icons.DELETE_OUTLINE, icon_color=DANGER,
                               icon_size=20, on_click=on_clear)
    voice_switch = ft.Switch(value=False, active_color=ACCENT, on_change=on_voice_toggle)
    auto_switch = ft.Switch(value=False, active_color=ACCENT2, on_change=on_auto_toggle)

    def quick_chip(label, cmd):
        return ft.Container(
            content=ft.Text(label, size=11, color=ACCENT),
            padding=ft.padding.symmetric(horizontal=12, vertical=7),
            bgcolor=BG_LIGHT, border_radius=20,
            border=ft.border.all(1, ACCENT_DIM),
            on_click=lambda e: send_text(cmd), ink=True,
        )

    quick_row = ft.Row([
        quick_chip("⏰ Time", "time kya hua"),
        quick_chip("🌐 Chrome", "chrome kholo"),
        quick_chip("💻 Code", "python ka calculator code likh de"),
        quick_chip("📅 Date", "date kya hai"),
    ], spacing=8, scroll=ft.ScrollMode.AUTO, wrap=True)

    chat_tab = ft.Column([
        ft.Container(
            content=ft.Row([
                ft.Column([
                    ft.Text("Chat", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Groq Llama 3.3 • Siri Voice", size=11, color=TEXT_DIM),
                ], spacing=2),
                ft.Container(expand=True),
                ft.Row([
                    ft.Text("Bolo 🔊", size=11, color=TEXT_DIM),
                    voice_switch,
                    ft.Text("Auto 🔄", size=11, color=TEXT_DIM),
                    auto_switch,
                    clear_btn,
                ], spacing=4),
            ]),
            padding=ft.padding.symmetric(horizontal=20, vertical=12),
            bgcolor=BG_MID,
            border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
        ),
        ft.Container(content=chat_list, expand=True),
        ft.Container(
            content=ft.Column([
                quick_row,
                ft.Row([txt_input, send_btn, mic_btn], spacing=8),
            ], spacing=8),
            padding=15, bgcolor=BG_MID,
            border=ft.border.only(top=ft.border.BorderSide(1, "#1f2947")),
        ),
    ], spacing=0, expand=True)

    # ===== COMMANDS TAB =====
    def cmd_card(icon, title, desc, cmd):
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Container(content=ft.Icon(icon, size=18, color=ACCENT),
                                 bgcolor=BG_DARK, padding=8, border_radius=8),
                    ft.Container(expand=True),
                    ft.Icon(ft.icons.ARROW_FORWARD, size=14, color=TEXT_MUTED),
                ]),
                ft.Text(title, size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                ft.Text(desc, size=11, color=TEXT_DIM),
                ft.Container(
                    content=ft.Text(f'"{cmd}"', size=10, color=ACCENT, italic=True),
                    padding=ft.padding.symmetric(horizontal=8, vertical=4),
                    bgcolor=BG_DARK, border_radius=6,
                ),
            ], spacing=8),
            padding=14, bgcolor=BG_MID, border_radius=12,
            border=ft.border.all(1, "#1f2947"),
            on_click=lambda e: send_text(cmd), ink=True, expand=True,
        )

    commands_grid = ft.Column([
        ft.Text("App Control", size=14, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
        ft.Row([
            cmd_card(ft.icons.LANGUAGE, "Chrome", "Browser", "chrome kholo"),
            cmd_card(ft.icons.CODE, "VS Code", "Editor", "vscode kholo"),
            cmd_card(ft.icons.CHAT, "WhatsApp", "Chat", "whatsapp kholo"),
        ], spacing=10),
        ft.Container(height=10),
        ft.Text("Quick Info", size=14, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
        ft.Row([
            cmd_card(ft.icons.ACCESS_TIME, "Time", "Abhi kya baje", "time kya hua"),
            cmd_card(ft.icons.CALENDAR_TODAY, "Date", "Aaj ki tareekh", "date kya hai"),
        ], spacing=10),
    ], spacing=10, scroll=ft.ScrollMode.AUTO)

    commands_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("Commands", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("Tap karo, JARVIS chalayega", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(content=commands_grid, padding=20, expand=True),
        ], spacing=0, expand=True), expand=True,
    )

    # ===== SETTINGS TAB =====
    settings_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("Settings", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("App config", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(
                content=ft.Column([
                    _card(ft.Column([
                        ft.Text("AI Model", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Row([ft.Text("Provider", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("Groq", size=12, color=SUCCESS)]),
                        ft.Row([ft.Text("Model", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("llama-3.3-70b", size=12, color=TEXT_MAIN)]),
                        ft.Row([ft.Text("Status", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text(brain.status(), size=12,
                                        color=SUCCESS if brain.client else DANGER)]),
                    ], spacing=8)),
                    ft.Container(height=10),
                    _card(ft.Column([
                        ft.Text("Voice", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Row([ft.Text("STT", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("✅" if VOICE_AVAILABLE else "❌", size=12,
                                        color=SUCCESS if VOICE_AVAILABLE else DANGER)]),
                        ft.Row([ft.Text("TTS", size=12, color=TEXT_DIM),
                                ft.Container(expand=True),
                                ft.Text("✅" if VOICE_AVAILABLE else "❌", size=12,
                                        color=SUCCESS if VOICE_AVAILABLE else DANGER)]),
                    ], spacing=8)),
                ], spacing=10, scroll=ft.ScrollMode.AUTO),
                padding=20, expand=True,
            ),
        ], spacing=0, expand=True), expand=True,
    )

    # ===== ABOUT TAB =====
    about_tab = ft.Container(
        content=ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("About", size=18, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                    ft.Text("JARVIS_V2", size=11, color=TEXT_DIM),
                ], spacing=2),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                bgcolor=BG_MID,
                border=ft.border.only(bottom=ft.border.BorderSide(1, "#1f2947")),
            ),
            ft.Container(
                content=ft.Column([
                    ft.Container(
                        content=ft.Column([
                            ft.Container(content=ft.Icon(ft.icons.SMART_TOY, color=ACCENT, size=40),
                                         bgcolor=BG_LIGHT, padding=20, border_radius=60,
                                         border=ft.border.all(2, ACCENT)),
                            ft.Text("JARVIS_V2", size=26, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                            ft.Text("Dina Wala • Aura 99999+", size=12, color=TEXT_DIM),
                            ft.Text("v2.0 • Siri Mode", size=11, color=TEXT_MUTED),
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
                        padding=30, alignment=ft.alignment.center,
                    ),
                    ft.Row([
                        _stat_tile(ft.icons.BOLT, "AI", "Llama 3.3", SUCCESS),
                        _stat_tile(ft.icons.MIC, "Voice", "Siri", WARNING := "#fbbf24"),
                        _stat_tile(ft.icons.TERMINAL, "Cmd", "10+", ACCENT),
                    ], spacing=10),
                    ft.Container(height=15),
                    _card(ft.Column([
                        ft.Text("Features", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MAIN),
                        ft.Divider(height=1, color="#1f2947"),
                        ft.Text("✅ Groq Llama 3.3 70B", size=12, color=TEXT_MAIN),
                        ft.Text("✅ Siri-style voice", size=12, color=TEXT_MAIN),
                        ft.Text("✅ Streaming replies", size=12, color=TEXT_MAIN),
                        ft.Text("✅ Memory (20 messages)", size=12, color=TEXT_MAIN),
                        ft.Text("✅ App control", size=12, color=TEXT_MAIN),
                    ], spacing=6)),
                    ft.Container(height=15),
                    ft.Container(
                        content=ft.Text("Made with ❤️ in Dina", size=12, color=ACCENT,
                                        weight=ft.FontWeight.BOLD),
                        alignment=ft.alignment.center,
                    ),
                ], spacing=10, scroll=ft.ScrollMode.AUTO),
                padding=20, expand=True,
            ),
        ], spacing=0, expand=True), expand=True,
    )

    # ===== TAB SWITCH =====
    content_area = ft.Container(expand=True)
    tabs = {0: chat_tab, 1: commands_tab, 2: settings_tab, 3: about_tab}

    def switch_tab(idx):
        state.current_tab = idx
        content_area.content = tabs[idx]
        refresh_nav()

    content_area.content = chat_tab
    refresh_nav()

    page.add(ft.Stack([
        ft.Row([
            sidebar,
            ft.Container(content=content_area, expand=True, bgcolor=BG_DARK),
        ], spacing=0, expand=True),
        overlay_container,
    ], expand=True))


if __name__ == "__main__":
    print("=" * 55)
    print("   JARVIS_V2 - Dina Wala")
    print("=" * 55)
    print(f"API Key: {'✅ Set' if GROQ_API_KEY.startswith('gsk_') else '❌ Missing'}")
    print(f"Brain: {brain.status()}")
    print("=" * 55)
    ft.app(target=main, assets_dir="assets")
